
import './style.css';
import 'flowbite'

import { Button, Modal } from 'flowbite-react';
import { useState } from 'react';
const User = () => {

  const [openModal, setOpenModal] = useState(false);
  const [openModal2, setOpenModal2] = useState(false);
  return (
    <>
      <div className="main">
        <div className="container">
          <div className="perfil">
            <img className="img" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw4QEA8PDw8NDg8NDQ0PEA8PDw8NDQ0NFREWFhURFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGA8QFy8mHyU3LysrKy0tLS0tLS8tKy0tLS0wLS0rLS0tLS0tLS0tLSstLS0tLS0tLS0tLSstLSstLf/AABEIAM0A9gMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAAAwIEBQEHBgj/xAA/EAACAgEBBQQFCgQGAwEAAAAAAQIDEQQFBhIhMRNBUWEicYGRoQcyQlKisbLB0eEUQ2JyU3OCwvDxIzODFv/EABcBAQEBAQAAAAAAAAAAAAAAAAIAAQP/xAAiEQEBAAICAgMBAAMAAAAAAAAAAQIREiEDMSIyQWETwfH/2gAMAwEAAhEDEQA/APDQACQAAJAAAkAACQA7g7wkkTuCagNhSbpmyFEkq2XIacfHTG6G5M5Uh2JqrTHf4YtM5sh0kXWzXemFz0xaXNlOJwvzoETqM0UyVwJuJzBhIgdwcJAAAkAACQAAJAAAkAACQAAJADp1Ik4kSSJJE1E3TNoKJOMCcYFqmk2QbSqqS5Vp/IsU0H0m7Ox+2sisZ5pDmO3LLNm6DYNtnSL9xoT3XvisuL9x7xs3Y2j0FKnaoZwsuSzh+CQ+vaOz7/Qar58vSil8Tdz8jON/a/OtmzpR5Si0Q/hD3jb25NNsXOnq1nh5PPqZ8XpdzbJW8PC+vTHQUkvcc8uWN1Y8/q2VOfzYv3Fp7q3tZ4X7j3TZW6Wl08eK7hk11zyiv1LM9s7OhJVYhzT6QWMLH6ozc/Js+N/bp+bNfseyvPFF+4ybdOfpfezdjT6iiV1MYp8PF6PSS8UeEbY2d2dko47zNSzcbu43VfJ20iJQNm6go21AsdJkouJFosSiQcQ6PZODgxoi0Y1EAAmgAAkAACQAAJA6kCJJEgkTUTsUMijdC5GJOMSUYjYQFIO3aqzQopF6es09NUORzyyT09B6V8mGjTug2ujz7uZ8PpqT0f5OIuNsOXfj3o6a6rjv5Rs/KVOUoqpPGYS5+Dff9x8Dsi+yUIT5ptekvqzXKS9jTR6ZvloJWyhhZzE+f2NupbGU04Phla5x5cvSw5fay/abhPjF5N3K9NndHXahtQ5yj4PuXj5H2DilmSiuJr1NlPZugjRXiKzLHPzfgKpjqVZxtZi+q4l095yy1lbZ/wBd8N4SS9/6fH707QvlJp5SWVjokfC62U1fp5NvEpW1+1wc1+Bns+3NkRvjxJLjXxPhNsbrW4jJQlmq2Fi5PueH9lyXtOuNmU6cM8cpl2+u3Ltc9M4S5pZXsaPJd9tGo3Tx3Sf3nsG6emddMs+P5HmG+dblbJ46yYZPlkWV+GLzzUUGbqKT6PU0mXqag2NxyYNtYmUTRvrKkogsdpVWUSDRYlEXKIdHKQ0RGtEGgtRAAJoAAJAAOokkkTijkUMijYLsUNjE5FDYIUg12MSxVEhGJZpiOQbVrTVmxodO5NJIoaaB6L8n2w1dZHi6dX6jpJ+uGXd1Frdjc+y3DccLvb5JHoezdhafSpScua72+FZObZ2tXo4KutJSS5LuivF+Z8bZtq22eZSb5lOWf8jbw8f9r0fWahQhx44umPac0eoc48bSiu79SpsuxX0KL6rCf5MhtrWKmNVceXaT4PUuCTX4Tlxn1127cr999Ianas+JqHReWSD2nd5e5Bs3R8fN9F18fUaj0NeMYx555nTK4Y9ac8Z5Mpvans/ablLhnjn0eMcyxr9a6msx4oy7/MytbQ65ermn4o1KJRvrw+qaz613mZY4zWWum45ZauO+1hWx4OJ+jGS558zA2rutRenKEll9OeYv2k98dbKqlKC4sc3FdXBeHn+h8lsveWcOGcJ8UJYa700WGF1uVnkzx3xyj5/eXdeyhvMWvuZ8Rq6cZTXQ/RtFtOvoaaWcc/GL8UeL75bL7G2Sx0k0KXfv2Fx46s9V8JqKyjZE19TAzrYgsdcapSiKki1OImSBY6Sq8kLaHyQqSDShTREm0RYScAAJAmiKJomJRQ2KIRGxFBpkEOghcEOghwaZBFqlCIItUjgVoaZHrnyXaqKlwvGZQaXrPJdMfTbv7QlTOLTawx63NOVurK9I332ZY59osuMkvY0uh8xpqmmk13n3Ww95KNTF1W8PElFPPzZZXwHarduuT46ml34fT2Msc+PxyWfj5fLA/dmlxq4n9LHwKW9dEuKmfVLUUP1elwv8Rr6iLqo4Yp5SS5fEjXFainhl85OL81KLyn8ATK8uf46XGcf8f77R2NasOPf19Zpny0nKuWOaafqHy2la1jifwT94s/DcruMw80k1TNqaqE5NRafZt1y8pp818S3sShxi5P6RgbD005zuTXJ6myX+l4Zv7T1HBGNcE8td3clgspqTxxmN3b5Kyd8KH87ua9x5xdobITcqU3Ccs2VL6z62Q8H4rv8AX19g1mm7elJr0mk+fLn3lLR7Bop9O1xbXPnyiv1LHySY6vuMy8WVz3PVU9x9DKuuVkuUZpYzy5eJ598o+pjO6bj3yZ9rvZvXGuuUNPzaXPHLiXhHwPI9o67t/TTypc1/13FjLu5VZWamM/GFqUZtyNTUmdajKWKpNCZoszQiaBXSK80JkixMTIFOEyIMZIWwkiAAY11E0QRNEwyI6ImI2IoNPgPgV4D4DgVYgWKytAsQY4NaWnZqaaRjUSNPTzOkcso2Nk6ucbbsN8ux/Cz0jdHadtk4x4pYbWV3YPKtBP8A8t3/AMvws9H3AmnbH2/cK/WhPvH3G09pqhxTWcoTVt2h4+jlpd3VvCMbfSTUo/2nx+s1bj2CT+dqqV7E3J/hOeHixuMtdM/LnM7I9XsqqkuNxUljOcZ5FaM9K3hJN+GJGXu9tVvFcstPo/A24aOuEpWY8/JAs4XVt/jrjlzm5J/UsVVJywoJ9cdWZmq3i08HFYbc58CfJelwt/7WYW8m25dtCC5VzjZFf5kcNe9cXuPlttXN18SfOqyu1eqMk39nK9o8fDNby9uWXmu9Y+nqug1vbQclyxlfA823w21dCcW5S4VaoS8lL0U/e0fa7nyzTJ9zax7jz3fJRlZZBrMZcUWvFM3CSZZSLyZW4Y2sHXXylnLPl7NUoWWwcZKPGnGWE4tuKb6eZqQvfOubzOtLm/5kO6f6+Zlylmdv90fwo3K7HGaJvlko2Fq5lSbBXSETETHzETBXSETFSGzEyBShUiDJyIMNNAAAxrqJIgSRI2I2LExYyLFBqxFj4MrRY6DHAqzBliDKkGPhIUCrtUi/RYZUJFmqwcoWNbRWf+Sz1Vfcz7fc3aSrtg33SR53prfTn/bX/uNfR6xxaaY5XPKdvdd4Nm/xNcZVtNpcvOLPmKt0b5zqclwqu3jbf+XOP3yRm7B32nVFRb4l4Png1NR8oPpKEVFNwlLPV8ml+bBJnjNQ7fHleV9vq9Lo6NLHik1lLq/yRVq3lrdnC+UXyz3rzPPto7yWWt5k37TNjrpJ5yKeOX7d0b5bOsJqPUts7Aq1MVOpxUlJTi/ouS+7w9p8/dutfxY4cp+1YMbZe9dlXST9XVM25/KDwxzwRljrj53rS7/UZrPH123fjy99PpNFp46HScMnlwi/f0ivdg8b3i11nay9HtY5fNNRsXk0+T9eV6jY3j3weri1GfLu4Hhwf/PE+H1GstTfFHtF9aDSl7Yv8mWM4+/dWV5WSeoVrdTGWGsxtjlwU04uXjHzT/Qzqr1KVkl0k0/P5q5FjUauuWYy5Z7pxcfvMrTPhnZDKbTb65eHzTfmG3ssZ0tWSK82TnIRORlKITYibGTYibBTiE2JkxkmKkw04hIWyUiDCUcAAMaDqOASMTGRYlMnFmsPix0WVosZFig1bhIbGRUjIdGQpQsXITHQmUoyGxmKUbFum305f2R+9l+q8xoz9P1x/MsxtFKNjbr1B2rU5tk/q1wXvbb/ACMmF52i/wBKb/qS90V+otjxfQrU+Z3+J8zFWoO/xIuQ8WvLUiZ6nzM16gVLUGbXFZ1PC3xc4y+tFuMvbjr7SlZdNfTUv7lwv3rl8CM7xM55DacjluozymuHPLPWL9v6lPs1GfLvhn4vkNs78d/VPmmUozanwt845XVPl1XMFpyLk5CZSCUhUpGWlI5OQqTOykKkw2lI5JipM7JkGwUo42RBnDCAABIAAEgSTIklEkmmMjIhGAyNXmKDU4yGRkchR5/AbHS/1fAUlG2OxmMjM7DRf1fAfDZ7+t8BSUdwjj9KPtQ5WE7dnNJS4/myjnl0TeG/cy3HY7+v9n9zZKNsVFYcos5PznP78fkaUNht/wAz7P7nNDsJyrhLtMccVL5vjz8RcazcU1ad7U1Vu2/8X7H7nf8A80/8X7H7m8cmbjIdpF2GvLdx/wCL9n9xUtgNfzPs/uXHJu4ynYQczTnsVr+Z9n9xE9kv6/2Q8atxnuZnWP0pPvUk/Ybc9mv6/wADHtqxOyOekkunXKyvuYMpXTGw1zyQlIlVp3yWeqb6dDstN5/AztdK8pC5MfKjzFSr8w0oU2QbJygQaCTgABNAABIAAEnUTiQROJMpsB8BEB0GODViBYrK0GWK2OBVqstVoqVss1yHHOragpJxfSSa9jH6GWYrPzl6Mv7lyZXrkSc+zlx/QljtP6Wuk/dyfqQ4xr0roS2Ol2FP+TWvaopCKrTuz7lHiqfWMpSj51ybax6s49g/1jbqrQ2VSKMLyb1A2JWwRTtiNncVbLTKiLUVLEWLJlW2QKlexHz+1YKNil0zJPyx/wBr4m3ffCPzpRj65JGRtG+maxxptPKxzOOfp1w9lU2Liw+XJr25yMmZfpdyk0ujw8oetVPHpQb88Nfkc5kdxOmV5hLUZ7sexi5WeXwZlrYjIXIlKfkQbDTRAAMaAACQAAJAkmROokbFjosrJjYyFKNW4SHwkUoyHQmKULF6EyzCZnQmOhYOULGnCwsQtMuFo6No5R0vQTj/AOuSivqNZh7PD/nIlZc5Y463mL5Srmm15pvDRUjcMVxu0fHUWr5s7PVOCn936k1rb/Gt/wCicf8AcV1cjvbItsqx/H2fVUvVlfeV7tXqZfNjXDzblJnHeQleW2TEidepl86/h8oRS/Uo6/QPCbssm0/pN4NCVwmyzILIctIq0lOE+BZ8+ZJqK6JL1JEXPAqdhje0pzK85BOYmcw2lI5OQmTOykKlIFpyOSYtnWyISgAAJoAAJAAAkAACTqJJkAJHRkNjMqpk1I3Y2LcbBsbCipjI2ClZpfjaMjaZ6sJq0Wx4tFXE1cZqtJK03kzi0e2O9uZ3ane1Lkzivu4i7ij2px2lyXFcdwuVpVdpB2Gcm8ViVguVgh2EHMOy0bKYqUxbmRcjNlIlKRBs5k4FoAAJoAAJAAAkAACQAAJAAAkAACTuTvERAkYpnVMUBM0erDvaCMhk3a0sdoHaFfIZLa0f2gdoIyGS2tGuw45izhbWk3I45EQMa7k4AEgAASAABIAAEgAASf/Z" alt="" />

            <div className='info'>

              <ul class="">
                <li>Nombre: Martin</li>
                <li>Carrera: DSM</li>
                <li>Edad: 19</li>
              </ul>

            </div>

            <div className='info'>

              <ul class="table">
                <Button className='btn' onClick={() => setOpenModal(true)}>Guku</Button>
                <Button className='btn' onClick={() => setOpenModal2(true)}> Vegueta</Button>


              </ul>

            </div>

          </div>
        </div>


      </div>
      <Modal className='center' dismissible show={openModal} onClose={() => setOpenModal(false)}>
        <Modal.Header>Goku</Modal.Header>
        <Modal.Body>
          <div className='modal'>
            <div className="space-y-6">
              <p className="text-base leading-relaxed text-gray-500 dark:text-gray-400">

                <img className="img2" src="https://lh3.googleusercontent.com/proxy/6c5skviNE4ZrQuWmcVNdk3pap7HfGs-CNNdtiH2jv-3WZQmKsmF49He-MsHGHT2fHlN4LCeQy468M-WSo3xxH57oeophyVooItU_lro1CesVlFv-u606BYK4vHDY2wZdA1nfVmxewx42BcZkmz-x" alt="" />

              </p>



            </div>

            <ul className='table'>
              <li> Nombre: Son Goku/Kakaroto</li>

              <li>Origen: Dragon Ball </li>

              <li> Genero: Masculino. </li>

              <li> Clasificacion: Dios Saiyan</li>

            </ul>
          </div>

        </Modal.Body>
        <Modal.Footer className='center'>
          <Button onClick={() => setOpenModal(false)} className='btn'>I accept</Button>
          <Button color="gray" onClick={() => setOpenModal(false)} className='btn'>
            Decline
          </Button>
        </Modal.Footer>
      </Modal>


      <Modal className='center' dismissible show={openModal2} onClose={() => setOpenModal2(false)}>
        <Modal.Header>Vegueta</Modal.Header>
        <Modal.Body>
          <div className='modal'>
            <div className="space-y-6">

              <p className="text-base leading-relaxed text-gray-500 dark:text-gray-400"> </p>

              <img className="img2" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgWFhYZGBgaHCUcHRocHB4hHB4eHyUeHhwcIRocIS4lHCErIRwaJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHxISHjQrISs0NDQ2NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAK4BIgMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAADBAIFAQYHAP/EAEMQAAIAAwQHBgQEBAUEAgMAAAECAAMRBBIhMQUiQVFxscEyYXKBkaEGE0KCUmKy0QfC4fAUI4OSohYzc/FEYxUXJP/EABoBAAMBAQEBAAAAAAAAAAAAAAABAgMEBQb/xAAnEQACAgICAQQCAgMAAAAAAAAAAQIRAxIhMQQUQVFhEzIi8AVxsf/aAAwDAQACEQMRAD8AhbbGrXic9WK60WWj4V7dPeLma3aPCFlSpBP4o9iznNenyACpphV+VITmWOqr4epja2sqkZbT0jIsSgLhsPMwbAaw1hND3ovSPT9Hm81drjqOsbTNlqKYfSOULWhL2f4xBsBqq2fIfmb2AiCSTQYfSx9zF2llN4YfU3IRNLLRRX8LczFAa98iB2mULgO5m5LF1OsZ3Uii0neUUrhfb+WExAC+snBecHWZh97dIr1apB3XR7wWpA+9ukRZVFwj1A7wnMwB8j9/MQJJtCn284YQhiR3NSKsQFhgfCkRYai8W/liwFmJBAH0pyjJshCLhtPSsACExKK3FORjKDVXg/IRZTLCSCN9z9MRl2IgAU/GPaAEJUOHFORgDrhT8r84updiJoKY1TkYZs/w+7gYZgjDvMTJ0UlZrgBzG9D6LFjo3Q7Ocjvy3Yn2xjcP+mElKPmFahhWlcRdwG40IIwx1olOslpIRbNJIArrPdUYjcxBNYwnmjFW2aQxtsTTRyIhLvSigClCpqcatWPSNKykUkEMb269jvHp7xW/9K2+aKul3Vpruo2g9lSaQP8A6LtgUqFQ62xxsrjiO+OOXlL2OmOAsp/xPQAKFAZj5YDLdmaxr834nmteF+uoBkcgRQZ7BEp/wxbUAJklgCTqMrHIbFNdm6NYe8hZWUqwwIYUIxGBByMZrK5dMt44x7Nkk/Er6oLntrhQcIlI+IZjFRU5tw4xqsqdrqafUOcHkTgCv38oe8iKib2JbuoJelUH0V+r3yg0/R5uuxJqCPpONa+mAr5RqVi000q4Qfo6kRuNm+JkJKuAwvAaxIwoRmNg4R0wzpGUsTfJVGzkUH5xyhRxRQabT0/eNsSRJtAYy2oVIOrUEVpmDuJplGp21HQhGF4VOsO15j9o64ZVIxnCjzbfAOYgbD9A6RlZlQe5BzH7xF2z8A6RrdmTMs4NfEOUYc1J8cQQarcR1hpUqT4xAIrmTE/vHofZMTHoANwTFT5RlFwHi/vlFRYdIURqnKkEfSJApXJqGJaKLUrgOJggTAeE84RsttvBa725Q4rggbrpiWBCauXAcohcGHiETmHv+kGIsaeTCAYFZeNe88oAUAFScLp5wzfxHiMVVsQ40JpdPOGhAbbaga7gBypWKK3rXA/jbpD87ANXZd5QCaMSDvflGlCKhLNnT8S8zAmlnEbmJ9aftFlIyPFeZhfC+eJ6xGo7AzVpdO27E5Ew1PAxmcwujwr1gEpsTwMDDstrPaipHBPeGV0hWgoK1flURVynFRwT2h2zWWr/AO7kYLCixS0g/wDDlBEm1p9/KCStDMVJA/CTwAx5wexaOYPjkL59QYlzQ9WW2hNHB1vkjBUNN5FBQ92MbJ8sL2EzJNBkK952AxX/AA9cFAalil78qgErQ9+HKB6d+NrNZ6qp+a/4UIug/mfIeVT3R5ubyXs1E7IYuLY5MstodyQZaUODsC7ZGpVMFXianhEpcxZGE62X2Jycy18gqgGnnGgztMaSt1RISZ8vdJVgMd8w5+oHdGsWzR06UymajLVmW8cVJGYDgkNQ12xySUpfszeLS/U7l81WAKMGU7QQR5EZwG0WhUArmTRRtYnYP37o5z8AzHV0VSbrg1WppnnTwo5843FHv2lmzCEIo3UAvHiWqPtEck/4to6oK1ZZ2ZHFWdqscSB2V/Ku/icz6DnH8VLIBNlzQMXUq3eVOB40YDyEdMWOffxXtK3ZEv6xec9wNFX1IPpF4G9kTmS1ZzorRwB+IdIymY+7lE2XXr+ZfeIDZxaPQPOITTgvh6mGmnsL2P1KfYwrevDwrT3/AKwcsKMD+JeRrCY4vkuNH6TZJwKtTXp3HHb3RtNg0ulpqhoGYgMuANRkQc6VxwjQ6Um/f1jNmYh1NaGuzPbFQyOLNZQ2RuVp0WyBmAqpU0I3AipO7GKyaMvCIXsennAZX1hdOIz2bNuUWCXXuFGBBUeRxwMehizKRxTxuICWmqeI6w7LTErtvgww1iVQauDlliYYSeiNgtTXON0Z0QNgf8BjMPHSbd/tGIKYGtXtVtlQp6wwTia/jHIxWFsD4F6Q0zdrxryMUBZyZ926PztyES//ACBCr4G9if6xXLNF4D87H1p+0ASaDhXJG96mE4gWJ0k1Dj9HURhrexJxprr1irlnB/D1EEbtU2l1PpnzEFAOyrW1Qb31nkIh/iyVxP0tzhVEIoc6O3IRhZLUy+huZgoCdpm4PXcn6f6wOY+sfE/6YzOs7UY0zC8ow6NeOGRevpFAKJgM87h9SYCRrE97D0r+8MslAOCczA0Wp+9+QiWAshqO6qD3MeVKE7iGp5QWzS8PuTmYm0ug8niGMGuDqO5OQi60JNHzQGqVvGtM6Y1oT3RQygby8RFjYGIcHbV/Yf36wn0C7Or6Kl30Uhxit0pShpSl2o7VKAnCIW+yOgYoVAK0wVmFQMSboJoTjFXoizTHS6owopvE0uNQUYUxrw3RtyCgArWgoTv748XLllGTR6OPHGUUzSNLaBE2QyByZiXcBRVFbxYMxajAhr1KjALHvhaw2Wyyx81LNNn5s8yajBe5VCsAoH1YE90bhNsMpnvtLRnpS8UBagyxI74OqgYAADdsjn/JKzZwi+xEacW0qZaTZVwdpZL3iVP0k0FwZjDPugVtsSTZbSXAuMKAbqZEbiO6G7To2TMF15SOO9RnvBGIipmaH+W16QxG+Wx1ftP0H2PdnETk3yaY4xXBX/Dvw41nZSzB7qlcN9cMOBb1i8s9kRKlRmSx4k1PuTE7NMvIGKlSRirChHcRFf8AEGmlsssOVvksFu1oaEGpyyFAPOMuZM1uhnSWkEs8tpr5Ls2s30qO8mOIab0g89zNc1Z6nuArgo7gKCLr4n+JXtTJq/LRGIVAa47WJwqdnd5xrdKqK/hY+8dmHHqrfZxZ8mzpdE27R8ScoEMx4mgrsAWO4ofaAS2q3mT6/wBiOk5WQlfV4eogs36uK8jAZe3w/tBpv1/bACGa1mV2Xh7nCMycCppXWoRXZ/dYErUY7r69YJJatPHE9M6IyUlRaybDLdSUJWqnv9oX/wABMBqrCoFBs9d8R0RaLjY5FGB6GLlwcT3co78CjON1ycmXaLqyEmY90h1FaLiDhl7GGXejE7jC7JgfCvSGmk9o945f0jrjGkYvkybX3RiAXTHookqZji61T9CU8qHlE5s41bH6x1hK1PSneg5ROe+L+NeRiXIdDCWj/MpX6jzMess6pJ/K3KF5f/d+88zA7IcT4G5GHYUOy3wfw9Vic6YQ9QcqEeg/aF72qe+XX3WMWl9Zvt5f0h2Aws9rta/UeQMO2a2YC9iLrc4pUmGgGeJPsP2hmW2oPA3MwgNgcq4ah2Jh5RGZI12+7LgYpZM9rrmuxYesNqdmxNag8jABmZZTQcE5mApZiKYfUx9hFkJhNBTYvMwZcD9zchAFFLZkp/uXrB/lgqODw4igjL6l5mAEUHk8IYlKsVTUbCPcxsehtDEsGIwq0IaKl3id9V54x0WzWcIiotCzg8VrtjDNPVGkI2zOjbItDrnEDUViKUyJumtSD7iLBJV1SoZjnQk1Ir3nPzrC6WBUdWUUNNbvwUfyiHY8LLLaTZ6cFrFIhZkYIt/tUFaZV2+VYKIyThGIyLIu0KGDvW6DvgIEJlxPUjVfjewNOMlEUsddiB+FQCfelO8iNslrnAJiKDfaguqReOxTQnkPSEnXI3zwcy0V/D+0zVvTWWQtSQGFWP2qdUcTDGmf4dNKlM8ueswopLIVummZIxNabo2LSemb4DM7JILNLN2qvfwu3yKMgYXiAO6pxpDXwvKdZ0yWXZ5RVGQsxaocthVqnIU4Aba13WVmEsMaOMT8n+3lALP2hDluUBpoGQYDyBIhSz9scY60zhkuTKjV+084nNyf7eUQXIeE849Mel4b7vsIYgn1HxLGJTUYeIRkjFuKxgDW++Ad0MJMpQjaCPcxt+ik+ZJrXFQVI8sI0kHBRx5mNp+F7eEYI9Lrg17qXqReHI4SNJR3jfuMTlphvUQdsm4jrFjpfR2TqKgrFMzmjeXWPUhPY4mqJ+sZha62+MxdiNatrdnwDrGbRM1mG9lPoCOsYtIqAdyA+5HWIWoa54jkIyky0OKdcH/7WEAs52/iV/YGCDt/6xhe/REPc49cOsKwoav4H/xdRHp2JbinuDC02YRd70A9/wCkHZ8W8ScjFbCozZe2B3/vBaaiY7G/UYVs8yjjxHrHhadVRuB9yTDtCoeldlvLnBbOxDCh2HkYRS0YEb6e0GSbQA7ake1OsOxFiLSRc7lEOratUH8zYcQP6xRvNBp3CnOGEfUFN56QwLRJn8vuTA3PJ4HLfBfs6wOY2A4tziQRZaJJBJy7POOlaCS9LEza+IO4ZAe0ctSYQDTcnuI6h8JvesUk7bgHpUHlHB5rqJ1YP2LMxiPR6PHZ3mIHNagpvgkLzGxhNlpWHdKqo7hAZgphDC9lT3QozVMEuhxJK9ARvii0jpOzuDL+ZU3gCy4qjgi7fIwALUFDnDs53d2RHCKq6z3bxLNWigVFKChJ7xGty9EzZEppHyZJUgAzlV2vijYuqKWqK5E0xwMSlZV0XUmyAzyCA11aTKgFSzEFFx2rrnuDjfEhahJlWq0kUChigywRbiAcWBP3QTRCBECKswqBUzHBDO+00bWJO8gDICsaR/EXT95v8Mh1UF5yD2noSF4Lz4ReOLcqJySSi2zQprVvHPs1PWBWcaw4x5GwYHbTnBJa0YeOnlHoI8xu2RUao8Lc4HNz8hyginVHhaITxj5DkIBGZZ1WO3A+8elnI/nEYTsv5c4lJyHiXrABNsLv3c4ds79g/lb+aEJpy4tzhuzPgncH5RMjbE/Y6H8NaZR1WVONKgBTxwpxiWmtC3LzLipxr3RoEueVKldgHWOkfCenlnJ8qbiRlXaP3zjfDmadE5cXuihNmO+PRuzaEk1P+YsZjs/Mc2hx2fKwHgH6oxaJYvMdxXlDMxcP9MfqiE5e39h9o11JsDa17VM/mHlCswaifdzhx8UJ3vX1BgE1dRPu6QnEaYO0ZJ4B1g0wYt4k5GA2gYJ4BzMMOMW4pyMSMFKXXB/ORCgMPy1xH/kPKESvKBjCNgadwPqAYYD6g8R5CFpx1vIchE3OH3HkIadCaDq8G+dqjxHksJSzgfL3MTrhT8zewH7RSkS4l1ZpgN2p/BzMMtJBUcW5xRi0XbnBDwpX94P/AIshVx2tzh7CovFlZ+FOkbN8MfERlyjZwheYrswxAW41GvXj+ZmWgxjTJWkKAClcE6QeVbqOHQ0dLxG44GqnuNI5/Jxfkg0uzbBNRmm+jpUvTz1F+QQKZo6t/wATdPpWLOz6QRxg2O4gg+hxjU9HW9ZyX17gy7VagND6+cN7I+bcpRdSR7ShGSuLNmmzKYQCNcVHXFHdMRUA3lPFXqB5UhqVpV17aBx+KXgQO+Wxr6E8INkw01Nid6IsVWl9IrIS8QWYkBEGbMSAOAqRU7K94j1q06hQFFd3bBUuMpqKHWLABAKjPyrC0myh5hLvemKys4HZXVqksVyAYh95N0nCkaMlIhPd7NenOLyMoabdGsjhQrMF+pDQVGYzxrghaPjuxoMGdyNgRh+qkbK8oOGRsVYFSO4ih5xwLSMlpbvLYUKMVNd64ReKEZdmeWTirRuOl/4hTJmpIT5YY0vsavjhhTBT6xpLtXE5m9/7gEvtLxHOJs2A4t70jsjCMejhnOUuwIGI4wyg1vuMLQ0va++KIBp2RwaMPQ1O4AdDBK4AdzQFMm4DmIAB4xINhTvr06xKdn5DkIHSAQY9lfOJJMoFPi98OsRJ1V4t0jDdlfPpANcDauCB3KOcOWaYVUkGhABBHGKpXGzYtD6w3Knar+FekS17o2hO+GbMPiWcMKDDu/pHop698eh7yL1XwHzU9yU/5D94XfEOfCPTDpE5czB/D1WBodV/LnHtHmkZK1CjfMHKIfKqEGyr8q9IaWXSg3TByiMsYrxflCoLFxJ1f9L3rE2TE8U/TGZRJvdyHpBHXE/ZyhUFgkXWHjPKA/LooP5W5wzMXA9znlA1GqPA/OCgsRtI1q/lX9IidoTPuYj2EHtCVDdyJT0AMEeXrHxt+kRLiVYsJdAKblPmSYwox+5+UGYYLwTmYig1vuf9MJqgTE5j1p3ACGENUXuDH0pCoWsMIcKbQrVhDDBzVR3JX0EGkzjfb7uRhO9rLwXkIPKU3zh+Lk0VYmi90RpEy5qt9LXVcbwwop4g0Nd1Y6XK0fsY4xyGzazqBtdF86gR3JpNI8X/ACGOO6kvc9LxJvVplc2jxsJ6QJtHHeIsiIzHm6napMr53+VLJAvOWARdhcghR3DaTsAMM2OzXFC1qSSWbazHtN5nZwEK2X/NmGd9CgpLGw/jmefZB3LX6osYf0KySxzn+Juhhq2lB2iEmU3/AEN5gFTwEdIQYGENLWAT5EySfrUgHc2anyaka45atMznHZNHAwlHHcwHvEZnZHiPSGZyEOQwoQ4BG4gkEQq/ZHE9I9BcnmyVOiCjbu/pBZ2TeIx4LQHwg+8ZnZHxdIYgcjPyPIxhMm4DmIzKahqdxHsQPePIuDcOogA9NzHAchEGzMGmIT5KDy/eMTJZq2GRhBTBhshs/ePFsAN3WCS5JLAd9IwibMzsGcAKLPSFJr4TDd0AGu1V6GLTRnw9OetVCKRm+ezJRjG1aP0FIlAMRfcU1m2UGxchGsMMpf6G5Rj9s1JZZoNVvQx6Omq4oMBHo19N9i/O/g5mJdA3ehPuP2gC9l/LnFiyYf6Z/V/SBNKF16D6U96Vj0DlMOdb/VEClHWA72PqP6QVwfmfeD54QGSdf15GACMgdrwHpBzt+zkYWknBvAekZnMQw4KfQCEASdk3jPKMKuqPC/OPYspO9+kYTsjwtzhgYmDBvCnIRJ8XIp9TH/jTpHpuIYflTkIxKm69d9eRhDPCXgMNiczGRLxHF+UGSZgK7k/UYICCR4n5QCKuVZtv5l9zEUs5q3BockEf8k5mII2LHubrE0NMAkjXX7ekNSgK/wC/9MeXacqKvIRmW38/6YdILIy2ugsPpZW/2m90jvEhw91hiGAYcCKjnHB5RwPEdYutA6etDPJkmY9xG+WqLRag1RakYsRXbuEcPl+O8slR04MqinZ1a2zVQ1ZlUbyQB7xQaV+ILNQS1tEsF2uswatxM3NVyJGqO9hujlWnbUHntdqVqtK7KCjYbMeUIhqAnflHHHwbbtnS/LpcI6+fi+wrRVnC6AAAqPSmAA7MDb47sQ+tzjTBG60jjzMbwx3chE1OI8X7RHpY/IvVS+DtFm+MbMyB1EwhnujVFSagZXsqt7GK/wD/AGBZLxqJgA23BT2aNQszXVkD8EhpzDfg7j1JSNVbI+FekX6WFIn1Mi8+L7TJe0vMkNeluVc4EUYjXBDCtaivnFFOUgAHfUcCBSMzxi/i/eLZbOJkhCuLJeHGiiojaGL2+jGUrdlQcj4RziM36vF+8SbI+Ec4EwxplE0KyAhoPgfAB7iDzNHOFvBarU0K4g5bsdsCKjhq9RA4tdopfQRNtWA1BjQn8O7GLBdFO98qyMKjEPht7orlUkG6CTdGQ7xD8uyzlZ2UXMsz37RtioQt8plSlXTLWx/DS3wZj1xyTD/ln7RdWKySpQFxFU76VbzbMxVSbS4IvkXr1DTL3iaWs6uP1ftHoRwxS4RyynJvsuWtOeOyFZ1rNRwiqFqqB4DziLT/ANNY1Soiy7Frbuj0Vy2g0GXpHodBYB5eH2H9RgcyXqt4E6RYT7OSFw384HMs7UIpmo9qQwEHk/5n3DpEJUkX8tp5GLB5WtjvHT9o8srXr3nH1gEVq2YAcUPP+kCnWfEV3DkIs3lEAUH0ke5gc5DQ8F5QUMSkpSg/P0gKLqDD6WiwSUcMPriVnsmqKj6WEFAVgFQ5psX2w6Rizprjz5GLdLDRG1cwOcCSx0apFM+RiaAREk6mNAQK+piLC6QTlefLhQc4I6moEDnLh9zfywARljLxJ1gaL2txDQdR2eKdYiVw8nhDBM2DeFIgjkAHxD1AEMXMG8KdIyZeoPEf5YAB2ZTQ13r1heyvR2INO0QduRh+fLuo3fcp5/8AuK3Jn7rw9iIS7tjQqmLDiOcFtyXbtMitR6svSB2cZtuEN6QkMWoAzBES8aEhSVDGtMheLYmOWbqDfz/w0XYgoxHlDFnks7oiirNMugd5IAgciWWZQoJJIAAxJJyoBGxWPRcyzhpz3UZWogvqzFmwLXVJIot7PaRHMmXQVmLWh1U6rSWs6bjRLicAzIp+6ELNoRnVyTdoikA1qctUUBxoa03Axd6JsIYVIOMbXPW/JZVRy9QwK4CpF1zjmWFBWvMw3JLllanP7P8ADrzZolKVW+4F9jRVFGqxO4DGFLPKeS9F1lDNQgEK9BSor3UPmI6Hb0e49+RVi4N8KKgAUpRPLZFfImNMogBmBAVVCcV1aVC1rkB6YwRywu7BwZpVusmp8xMVKCoGwhsfKI2aUsxSrdpSKHbQ09cY36XotHdEV1S8lwoQwC622+TSpJbzir0h8HTZD/NUqZZUNQGpzu4DaAQSe7GNYauVmck0jWJbvZzdOK3iO7ZiNx7otfmhgCQp1K5A7YJOs9cGFRfNQYq5C3bwB1bpp3d0dUYU+OjNssmtGB8A5iIWmfi/l0hH5lR9nuDGZr9vgP5Y2pEjRmY/f+0BSZUDxxF31u6+OUDltl4+kFiCo/6W6xNTgfB1ELI4AHhYetYIr4fZ1hWBZymFBwj0Ly5goOEehiL8W6gXDZ1MOrOVqcNsa87aq8DzMFSaQQfyj9oqgLudYgT9wMQexgZ7z0j0i2Ymu9eUOTiCMN56RNjEnlCgwGXWAWizAg4bFh9lwH97YwVwPEdYLAqVkEMBT66/vDEiy0A2YNDRXX+6IBsF84LEAWQaNjs6wpOs5i4IGXcIk0rV8+kKwNUn2Y1GEJzVxp3n3/8AUbg9ir3YxX2nQ4xoTnDsZRBMvs6x5ZOHk3OLKZo5kpXLV9qxiRZSaDeH5xMgRPRuhzNYItKsFAxAHmTllFhpT4aEu4qvfBW+SVK0vAYUOYwz2w5Zp4lS2X8aoCKYkVr5YxRab0u7AICdtBU4AUoOEYycn0aqKKzSzi9cXFVulm2E0wA7s4qrMULOXaii812tC2wKpoaE1zIwAMP2qxOqK74JMulaUqQMN9e6KyY4FaKO0cdsN24q3Qe5KyBKqHJVCwvmhNErjlicN0HsNtmiY0xGKs5Ykg78fMbKHDZEbMzHDA1phSOmaE+B3MtZloKSVAJo2DCuV6pAXZmaxjlcWlz0VFM17RMiZON1LPJRmwLIgVjneozHU1a4JdGJi1sHwojG85ot+9Tb6bsI2uTo6QJYEi0SHeoxLqVIqSAApqDljXZlALdZLWms0lXSuct8e7VdQD/ujgz5JJfwRvFL3PSrFJQi7UU/uv8Ae+CWm+FJVlbLtavoVqK+UV1m0igN1wyOwN1HF0mmJpXBht1ScozbbaqqXd6KKDz2AKMydwjzZ58nTXPwbxivYhM0ilaOGlknC/QAnucap9a4xi1WFJlGdcdjg3WHBxiIpdKabCrSZSUjDsMoea4/8Z1UB3tXhGrSdPMBcSWHozXWmkuQMaC4SEBpuEPH4uTI7XDCU4x7Num21ZWpOdJ8qlA95fmpU4XqGrL+YY7xFks9h/2JgdQOxeBONK0O6lMDHNm+IrUQde6KUoqIB7LGLJpx5YCsktwtKXlow4OtCPeO5ePngr/rMXlhI3LTDK6AqFVhMYE3aHWqTf4HLDAYRps9suFK+ZiwnaXSawKlpbFiXDvfRqDVCvSoJyx7oRABVSMiK+5j1fHm5Kn2cuRJPgAlce8U8jBrQDecUzUfyxkrBLQuPkOQjr1MwRrUeNT7RCWpp946w6g2/mXrElGz89ef7xOoFZ8tqDDfzhhZZp9h5mHnk4DiY8kqo+0wa0BV0Meiw/ww/sR6HQqLC9gPC3OME/oHOF75xG5W5ExJTgfAOYihDaTsSfzL1i0s1prgcrx6RryvRW4jrB5doN3g3QQhm0YYcD1iIyPlFKlteoFdjdYspE+8pr3RDQBJmde+BuuqvnGHbE8Yw5wHnABItQ+Q5QUzKDz6Qs5x8hEnOHnAA4szD0PvE0cVMKKcBwHODyEqfMwnwNIs7No35i3sKAqM8a8N1DXyMIaRsQlG6MWN67TdXPhF1Ici6i0qwAxwGG002xeWbQCYtNJmPtrgvko6xyTy12aqKNDs2iHcNW8SQtKY5Z1wr6REfB80kkI5z2EZ8Y6I2kVE15EmWL6AHWN1NmRUE7d0MLItBrWZLWmxEJ/5Oxr6CI9TJdFanJbX8C2tsElH6cyoy4mFj/D21kgfKprGuK4ZYk1jsZsc0/8AyJg8KyxThVDATo+cdUWuatBSoSTU99Shx8ozlnlJ8jUUjWNBfC8jR6CbOHzZ7EKiKKm+folrtY41Y5CpNADGzWTRRc/NtISZNzVO1LlA/QgI1jvcirHcKANWPRiI3zNZ5hFDMdizU3CuCDuUAQ9GTdlAXs6MKMiEbioPMQhN0JKAJl1kNiay9UV3tLxR/Na8ItYV0jMuoSNuEKgNJlMJyvJnopeWReA7LA4o6bVrTiCCK4Rz/wCJbZMssx5dSz4XJr5rLI1QoyD53n2kR0Jh/wD0k7TJAPk7U6+sc3/iVaa2u7TsS1HGtX/mA8oekZPlA5NdGtJV2qxvEmpJNScd+2LFMGpueKmS5BrF1bZQWXLcEn5hZiDTAh3TDyWvGPY8TTThcnNktu2JGAWwY1GWHLHlBjvgc8ap7qdY3zxuDJg6YKXs8Qg9htN2inskHyMT0LJDz5KtirTUBG8EgEe8JqcB4W6x5MZOMrRs1aLtlp5j+kGeWK+Q/SIVsT3kUbhT3J6wyEqc49GEtlZk1QzKkC6eI5GGZVlBIJ3wGzDA8RyMWlikjbFMRlbGpA4mDJYxTLYYcSUAo4mCqMuETYyr/wAHw9ozFpcG4ekehWI//9k=" alt="" />








            </div>
            <ul className='table'>

              <li> Nombre: Vegetao</li>

              <li>Origen: Dragon Ball </li>

              <li> Genero: Masculino. </li>

              <li> Clasificacion: Guerrero Elite | Sayajin |  Guerrero Z </li>

            </ul>

     

        </div>

      </Modal.Body>
      <Modal.Footer className='center'>

        <Button onClick={() => setOpenModal(false)} className='btn'>I accept</Button>
        <Button color="gray" onClick={() => setOpenModal(false)} className='btn'>
          Decline
        </Button>

      </Modal.Footer>
    </Modal >



    </>


  );

}

export default User